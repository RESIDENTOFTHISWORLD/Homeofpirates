<noscript>
  <p class="noscript">Bitte aktiviere Javascript für vollständigen Funktionsumfang!
  </p>
</noscript>

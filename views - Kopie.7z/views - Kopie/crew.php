<div class="content">
  <div class="container">
    <div class="box">
      <div class="imageHeader">
        <picture>
          <img src="img/crew_white.svg" alt=""/>
        </picture>
      </div>
    </div>
    <div class="box">
      <div class="textHeader">
        <h2>Atmosphäre seit <?= $controller->alter();?> Jahren</h2>
        <p>
          Atmosphäre schaffen ist unsere Leidenschaft, alles aus einer Hand.
          Flexibilität und Vielfalt ist unsere Stärke, Erfahrung eine beruhigende Grundlage,
          Resultat von hunderten realisierten Projekten. Unsere motivierte Crew steht Ihnen gerne zur Seite.
        </p>
      </div>
    </div>
  </div>
</div class="content">
